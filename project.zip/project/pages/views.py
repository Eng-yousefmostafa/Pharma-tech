from django.shortcuts import render
# Create your views here.
def index(request):
    return render(request,"pages/index.html")
def PatientHistory (request):
    return render (request , "pages/PatientHistory.html")

def CurrentCard(request):
                
    return render (request , "pages/CurrentCard.html")


def Report(request):
                
    return render (request , "pages/Report.html")


def servay(request):
                
    return render (request , "pages/servay.html")
