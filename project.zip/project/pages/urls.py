from django.urls import path
from . import views
urlpatterns = [
    path ("",views.index,name="index"),
    path ("PatientHistory", views.PatientHistory , name = "PatientHistory"),
    path ("CurrentCard", views.CurrentCard , name = "CurrentCard"),
    path ("Report", views.Report , name = "Report"),  
        path ("servay", views.servay , name = "servay")  

]
