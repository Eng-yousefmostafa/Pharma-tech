from django.db import models

# Create your models here.
class PatientHistoryData (models.Model):
    # name = models.CharField(max_length=100)
    CBC = models.ImageField(upload_to="phtosCBC/%y/%m/%d")
    Test = models.ImageField(upload_to="phtosCBC/%y/%m/%d")
    GeneticDiseases = models.BooleanField(default=False)
