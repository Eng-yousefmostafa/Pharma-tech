from django.contrib import admin

from . models import PatientHistoryData
# Register your models here.
admin.site.register(PatientHistoryData)
